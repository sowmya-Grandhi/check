﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using Newtonsoft.Json;

namespace ASP.NET_MVC_Application.Models
{
    public class stock
    {
        public int productId { get; set; }
        public string productName { get; set; }
        public string Quantity { get; set; }
        public int price { get; set; }

        public virtual ICollection<productprice> productprices { get; set; }

    }
}